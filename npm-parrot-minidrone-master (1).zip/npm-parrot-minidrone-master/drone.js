const Drone = require('./lib/Drone');
module.exports = Drone;
